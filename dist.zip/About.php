 

<section id="content">
	<section class="section-padding">
		<div class="container">
			<div class="row showcase-section">
				<div class="col-md-6">
					<img src="<?php echo web_root; ?>plugins\home-plugins\img\slides\PESO SAN JUAN LOGO.jpg" alt="showcase image" style="width: 40%;left: 47%;
    position: absolute;">
				</div>
				<div class="col-md-6">
					<div class="about-text">
						<h3>PESO - SAN JUAN BATANGAS</h3>
						<p>PESO aims to fill job vacancies through referral and placement, career counseling, trainings, and seminars. PESO accommodates various individuals including job seekers, employers, students, out-of-school youth, migratory workers, and persons with disabilities.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	</section> 
 